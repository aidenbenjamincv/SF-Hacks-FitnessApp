//
//  Fitness_PlannerApp.swift
//  Fitness Planner
//
//  Created by London Petway on 3/5/21.
//

import SwiftUI

@main
struct Fitness_PlannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
